package com.example.project_stimulus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
